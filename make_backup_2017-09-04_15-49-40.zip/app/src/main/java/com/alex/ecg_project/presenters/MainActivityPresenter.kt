package com.alex.ecg_project.presenters

import android.content.Context
import com.alex.ecg_project.ui.activities.Contract

class MainActivityPresenter(val context: Context): Contract.MainActivityPresenter {

  override fun subscribe(view: Contract.MainActivityView) {

  }

  override fun unsubscribe() {

  }
}