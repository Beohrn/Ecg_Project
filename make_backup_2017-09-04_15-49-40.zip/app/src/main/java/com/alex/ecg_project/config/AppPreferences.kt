package com.alex.ecg_project.config

import android.content.Context

class AppPreferences(val context: Context)